<?php
session_start();
$_SESSION["room"] = "";

$ok = true;
include "dbconnect.php";
if(isset($_REQUEST["room"]) && isset($_REQUEST["useid"]) && isset($_REQUEST["pwd"])){
	$roomid = $_REQUEST["room"];
    $userid = $_REQUEST["useid"];
    $password = $_REQUEST["pwd"];
    
    $sql = "SELECT * FROM LaundryProject.Unit where UserID = '".$userid."' AND UserPassword = '".$password."'";	
    $result = mysqli_query($connect, $sql);
    if(mysqli_num_rows($result) > 0){
        $connect->close();	//nessessary?
		$_SESSION["room"] = $roomid;
        $_SESSION["useid"] = $userid;
        $_SESSION["pwd"] = $password;
		echo "Logged In Successfully!";
        header("Location: dTable.php");
        
        
    }
    else{
        $ok = false;
    }
	if(!$ok) echo "<p> INVALID USERNAME/PASSWORD!";
    
}

//include "index.html";
?>
<?php
session_start();
//$_SESSION["day"] = "";
include "dbconnect.php";


$sql2 = "SELECT * FROM LaundryProject.schedule where Unit_RoomNo = '".$_SESSION["room"]."'";
$result2 = mysqli_query($connect, $sql2);
if(mysqli_num_rows($result2) > 0) {
  echo "You already made an appointment!<br>";
  while($row = mysqli_fetch_assoc($result2)){
	echo "Your apppointment is on " . $row["Day"]. ". " . "<br>";
  }
} 
else {
	$day = $_POST["day"];
	$sql = "INSERT INTO LaundryProject.schedule (Day, Hour, Unit_RoomNo) VALUES ('".$day."', '0', '".$_SESSION["room"]."')";
	$result = mysqli_query($connect, $sql);
	$sql3 = "SELECT * FROM LaundryProject.schedule where Unit_RoomNo = '".$_SESSION["room"]."'";
	$result3 = mysqli_query($connect, $sql3);
	while($row2 = mysqli_fetch_assoc($result3)){
		echo "You successfully made an appintment!<br>";
		echo "Your apppointment is on " . $row2["Day"]. ". " . "<br>";
	}
}
$connect->close();

?>

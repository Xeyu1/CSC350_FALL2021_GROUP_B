<?php
$ok = true;
include "dbconnect.php";
if(isset($_REQUEST["room"]) && isset($_REQUEST["useid"]) && isset($_REQUEST["pwd"])){
	$roomid = $_REQUEST["room"];
    $userid = $_REQUEST["useid"];
    $password = $_REQUEST["pwd"];
    
    $sql = "SELECT * FROM LaundryProject.Unit where UserID = '".$userid."' AND UserPassword = '".$password."'";  //create query string
    $result = mysqli_query($connect, $sql);
    if(mysqli_num_rows($result) > 0){  
        $ok = false;
    }
    else{
        $sql = "INSERT INTO LaundryProject.Unit (RoomNo, UserID, UserPassword) VALUES ('".$roomid."','".$userid."','".$password."');"; //create query string
        $result = mysqli_query($connect, $sql);
        $connect->close();
        header("Location: index.html");   //redirect to register.php
    }
}

$inputtype = "SIGN UP";
$handlername = "signup.php";

include "register.html";
?>
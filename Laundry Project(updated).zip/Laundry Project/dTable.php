<?php
    
if(isset($_REQUEST["Day"] && $_REQUEST["Hour"]))
{
    echo "You already signed up for one slot.";
    header("location: cSchedule.php");
}else{

<html>
    <style>
        table{
            border: 1px solid black;
            width: 100%;
        }
        tr, td, th{
            border: 1px solid black;
        }
    </style>
<head>
    <title>
        TimeSchedule
    </title>
</head>

<body>
    <form action="cSchedule.php" method="post">
    <table>
        <tr><th colspan = "7"><h2>Time Slots</h2></th></tr>
        <tr>
            <td><h3>Monday</h3></td><td><h3>Tuesday</h3></td><td><h3>Wednesday</h3></td><td><h3>Thursday</h3></td><td><h3>Friday</h3></td><td><h3>Saturday</h3></td><td><h3>Sunday</h3></td>  
        </tr>
        <tr>
            <td>
                <!--Change xx to data-->
                <!--Not sure if this works: <?php echo $row->xx;?>-->
                <a href="cSchedule.php ?=     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">00:00 - 03:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">00:00 - 03:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">00:00 - 03:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">00:00 - 03:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">00:00 - 03:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">00:00 - 03:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">00:00 - 03:00</a>
            </td>
        </tr>
        <tr>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">03:00 - 06:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">03:00 - 06:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">03:00 - 06:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">03:00 - 06:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">03:00 - 06:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">03:00 - 06:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">03:00 - 06:00</a>
            </td>
        </tr>
        <tr>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">06:00 - 09:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">06:00 - 09:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">06:00 - 09:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">06:00 - 09:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">06:00 - 09:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">06:00 - 09:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">06:00 - 09:00</a>
            </td>
        </tr>
        <tr>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">09:00 - 12:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">09:00 - 12:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">09:00 - 12:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">09:00 - 12:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">09:00 - 12:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">09:00 - 12:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">09:00 - 12:00</a>
            </td>
        </tr>
        <tr>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">12:00 - 15:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">12:00 - 15:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">12:00 - 15:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">12:00 - 15:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">12:00 - 15:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">12:00 - 15:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">12:00 - 15:00</a>
            </td>
        </tr>
        <tr>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">15:00 - 18:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">15:00 - 18:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">15:00 - 18:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">15:00 - 18:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">15:00 - 18:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">15:00 - 18:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">15:00 - 18:00</a>
            </td>
        </tr>
        <tr>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">18:00 - 21:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">18:00 - 21:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">18:00 - 21:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">18:00 - 21:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">18:00 - 21:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">18:00 - 21:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">18:00 - 21:00</a>
            </td>
        </tr>
        <tr>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">21:00 - 24:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">21:00 - 24:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">21:00 - 24:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">21:00 - 24:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">21:00 - 24:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?')">21:00 - 24:00</a>
            </td>
            <td>
                <a href="cSchedule.php ?xx =     
                <?php echo $row->xx;?>" onclick="return confirm('Are You Sure?  ')">21:00 - 24:00</a>
            </td>
        </tr>
    </table>
    <p>Note: You can only sign up one slot per week.</p>
    </form>
</body>
</html>
}
?>
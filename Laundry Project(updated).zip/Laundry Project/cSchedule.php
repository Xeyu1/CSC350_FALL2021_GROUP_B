<?php
include "dbconnect.php";

// $sql = "SELECT xx(), xx() FROM xx()";   //day, timeslot from table
// $result = $conn->query($sql);

// if ($result->num_rows > 0) {
//     // output data of each row
//     while($row = $result->fetch_assoc()) {
//         echo "You successfully made an appointment."."<br>";
//         echo "Your apppointment is on " . $row["day"]. " " . $row["time slot"]. " " . "<br>";
//     }
// } 

//change data name (this should insert data)
$sql = "INSERT INTO MyGuests (firstname, lastname, email) VALUES ('John', 'Doe', 'john@example.com')";

if ($conn->query($sql) === TRUE) {
  echo "You successfully made an appointment!";
  echo "Your apppointment is on " . $row["day"]. " " . $row["time slot"]. " " . "<br>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
include "dTable.html";
?>
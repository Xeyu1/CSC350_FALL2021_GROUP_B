<?php
session_start();
$_SESSION["useid"] = "";
$ok = true;

if(isset($_REQUEST["useid"]) && isset($_REQUEST["pwd"])){
    echo "Logged In Successfully!";
    $userid = $_REQUEST["useid"];
    $password = $_REQUEST["pwd"];
    include "dbconnect.php";
    $sql = "SELECT * FROM Laundry.Unit where UserID = '".$userid."' AND UserPassword = '".$pwd."'";
    $result = mysqli_query($connect, $sql);
    if(mysqli_num_rows($result) > 0){
        $connect->close();
        $_SESSION["useid"] = $userid;
        $_SESSION["pwd"] = $pwd;
        header("Location: dTable.php");   //This should direct to the table
        
        
    }
    else{
        $ok = false;
    }
}
$inputtype = "SIGN IN";
$handlername = "signin.php";
include "index.html";
?>
<?php
	session_start();
    include "dbconnect.php";
	
	$sql = "select Day, RoomNo
			from LaundryProject.schedule
			join LaundryProject.unit
			on LaundryProject.schedule.Unit_RoomNo = LaundryProject.unit.RoomNo
			where RoomNo = '".$_SESSION["room"]."'";
	$result = mysqli_query($connect, $sql);
if(mysqli_num_rows($result) > 0) {

    //echo "You already signed up for one slot.";
    header("location: cSchedule.php");
}else{

	header("location: dTable.html");
}

?>
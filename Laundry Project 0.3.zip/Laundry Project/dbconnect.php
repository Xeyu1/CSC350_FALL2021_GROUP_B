<?php 
    $servername = "localhost";
    $username = "root";
    $password = "root";
    $connect = mysqli_connect($servername, $username, $password);
    if(!$connect)
        die("Error!");
	else
		echo "Connected.";
?>
<?php
session_start();
//$_SESSION["day"] = "";
include "dbconnect.php";
?>
<html>
<head>
<title>
</title>
<style>
	.center{
			margin: auto;
			width: 50%;
			padding: 10px;
			text-align: center;
		}
</style>
</head>
<body>
	<div class="center">
		<img src="apartLogo.jpg" alt="ABC Apartment"><br>
		<h style="font-size:30px">
        ABC Apartment Laundry
		</h>
<?php
$sql2 = "SELECT * FROM LaundryProject.schedule where Unit_RoomNo = '".$_SESSION["room"]."'";
$result2 = mysqli_query($connect, $sql2);
if(mysqli_num_rows($result2) > 0) {

  echo "<h2>You already made an appointment!</h2><br>";
  while($row = mysqli_fetch_assoc($result2)){
	echo "<h2>Your apppointment is on </h2><br><h1>" . $row["Day"]. ". " . "</h1>";
  }
} 
else {
	$day = $_POST["day"];
	$sql = "INSERT INTO LaundryProject.schedule (Day, Unit_RoomNo) VALUES ('".$day."', '".$_SESSION["room"]."')";
	$result = mysqli_query($connect, $sql);
	$sql3 = "SELECT * FROM LaundryProject.schedule where Unit_RoomNo = '".$_SESSION["room"]."'";
	$result3 = mysqli_query($connect, $sql3);
	while($row2 = mysqli_fetch_assoc($result3)){
		echo "<h2>You successfully made an appintment!</h2><br>";
		echo "<h2>Your apppointment is on </h2><br><h1>" . $row2["Day"]. ". " . "</h1><br>";
	}
}
	
$connect->close();

?>
</div>
</body>
</html>

<?php
session_start();
include "dbconnect.php";
?>

<html>
    <style>
        table{
            border: 1px solid black;
            width: 100%;
        }
        tr, td, th{
            border: 1px solid black;
        }
		.center {
			margin: auto;
			
			padding: 10px;
			text-align: center;
		}
    </style>
<head>
    <title>
        TimeSchedule
    </title>
</head>

<body>
<div class = "center">
	<img src="apartLogo.jpg" alt="ABC Apartment"><br>
	<h style="font-size:30px">
        ABC Apartment Laundry
	</h>
    <form action="cSchedule.php" method="post">
		
    <table>
        <tr><th colspan = "7"><h2>Time Slots</h2></th></tr>
        <tr>
		
		
            <td><h3>Monday</h3></td><td><h3>Tuesday</h3></td><td><h3>Wednesday</h3></td><td><h3>Thursday</h3></td><td><h3>Friday</h3></td><td><h3>Saturday</h3></td><td><h3>Sunday</h3></td>  
        
		
		</tr>
        <tr>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Monday 00:00 - 03:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Monday 00:00 - 03:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>00:00 - 03:00</button>
            </td>
			<td>
				<button onclick="return confirm('Are You Sure?')" name = "day" value = "Tuesday 00:00 - 03:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Tuesday 00:00 - 03:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>00:00 - 03:00</button>
			</td>	
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Wednesday 00:00 - 03:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Wednesday 00:00 - 03:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>00:00 - 03:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Thursday 00:00 - 03:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Thursday 00:00 - 03:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>00:00 - 03:00</button>
            </td>
            <td>
				<button onclick="return confirm('Are You Sure?')" name = "day" value = "Friday 00:00 - 03:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Friday 00:00 - 03:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>00:00 - 03:00</button>            
			</td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Saturday 00:00 - 03:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Saturday 00:00 - 03:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>00:00 - 03:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Sunday 00:00 - 03:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Sunday 00:00 - 03:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>00:00 - 03:00</button>
            </td>
        </tr>
        <tr>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Monday 03:00 - 06:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Monday 03:00 - 06:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>03:00 - 06:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Tuesday 03:00 - 06:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Tuesday 03:00 - 06:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>03:00 - 06:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Wednesday 03:00 - 06:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Wednesday 03:00 - 06:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>03:00 - 06:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Thursday 03:00 - 06:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Thursday 03:00 - 06:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>03:00 - 06:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Friday 03:00 - 06:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Friday 03:00 - 06:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>03:00 - 06:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Saturday 03:00 - 06:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Saturday 03:00 - 06:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>03:00 - 06:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Sunday 03:00 - 06:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Sunday 03:00 - 06:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>03:00 - 06:00</button>
            </td>
        </tr>
        <tr>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Monday 06:00 - 09:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Monday 06:00 - 09:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>06:00 - 09:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Tuesday 06:00 - 09:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Tuesday 06:00 - 09:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>06:00 - 09:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Wednesday 06:00 - 09:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Wednesday 06:00 - 09:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>06:00 - 09:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Thursday 06:00 - 09:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Thursday 06:00 - 09:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>06:00 - 09:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Friday 06:00 - 09:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Friday 06:00 - 09:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>06:00 - 09:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Saturday 06:00 - 09:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Saturday 06:00 - 09:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>06:00 - 09:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Sunday 06:00 - 09:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Sunday 06:00 - 09:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>06:00 - 09:00</button>
            </td>
        </tr>
        <tr>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Monday 09:00 - 12:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Monday 09:00 - 12:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>09:00 - 12:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Tuesday 09:00 - 12:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Tuesday 09:00 - 12:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>09:00 - 12:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Wednesday 09:00 - 12:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Wednesday 09:00 - 12:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>09:00 - 12:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Thursday 09:00 - 12:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Thursday 09:00 - 12:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>09:00 - 12:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Friday 09:00 - 12:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Friday 09:00 - 12:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>09:00 - 12:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Saturday 09:00 - 12:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Saturday 09:00 - 12:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>09:00 - 12:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Sunday 09:00 - 12:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Sunday 09:00 - 12:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>09:00 - 12:00</button>
            </td>
        </tr>
        <tr>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Monday 12:00 - 15:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Monday 12:00 - 15:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>12:00 - 15:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Tuesday 12:00 - 15:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Tuesday 12:00 - 15:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>12:00 - 15:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Wednesday 12:00 - 15:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Wednesday 12:00 - 15:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>12:00 - 15:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Thursday 12:00 - 15:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Thursday 12:00 - 15:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>12:00 - 15:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Friday 12:00 - 15:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Friday 12:00 - 15:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>12:00 - 15:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Saturday 12:00 - 15:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Saturday 12:00 - 15:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>12:00 - 15:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Sunday 12:00 - 15:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Sunday 12:00 - 15:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>12:00 - 15:00</button>
            </td>
        </tr>
        <tr>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Monday 15:00 - 18:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Monday 15:00 - 18:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>15:00 - 18:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Tuesday 15:00 - 18:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Tuesday 15:00 - 18:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>15:00 - 18:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Wednesday 15:00 - 18:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Wednesday 15:00 - 18:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>15:00 - 18:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Thursday 15:00 - 18:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Thursday 15:00 - 18:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>15:00 - 18:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Friday 15:00 - 18:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Friday 15:00 - 18:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>15:00 - 18:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Saturday 15:00 - 18:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Saturday 15:00 - 18:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>15:00 - 18:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Sunday 15:00 - 18:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Sunday 15:00 - 18:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>15:00 - 18:00</button>
            </td>
        </tr>
        <tr>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Monday 18:00 - 21:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Monday 18:00 - 21:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>18:00 - 21:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Tuesday 18:00 - 21:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Tuesday 18:00 - 21:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>18:00 - 21:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Wednesday 18:00 - 21:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Wednesday 18:00 - 21:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>18:00 - 21:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Thursday 18:00 - 21:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Thursday 18:00 - 21:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>18:00 - 21:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Friday 18:00 - 21:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Friday 18:00 - 21:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>18:00 - 21:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Saturday 18:00 - 21:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Saturday 18:00 - 21:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>18:00 - 21:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Sunday 18:00 - 21:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Sunday 18:00 - 21:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>18:00 - 21:00</button>
            </td>
        </tr>
        <tr>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Monday 21:00 - 24:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Monday 21:00 - 24:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>21:00 - 24:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Tuesday 21:00 - 24:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Tuesday 21:00 - 24:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>21:00 - 24:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Wednesday 21:00 - 24:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Wednesday 21:00 - 24:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>21:00 - 24:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Thursday 21:00 - 24:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Thursday 21:00 - 24:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>21:00 - 24:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Friday 21:00 - 24:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Friday 21:00 - 24:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>21:00 - 24:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Saturday 21:00 - 24:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Saturday 21:00 - 24:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>21:00 - 24:00</button>
            </td>
            <td>
                <button onclick="return confirm('Are You Sure?')" name = "day" value = "Sunday 21:00 - 24:00"
				<?php $sql = "select * from LaundryProject.schedule where Day = 'Sunday 21:00 - 24:00'";
				$result = mysqli_query($connect, $sql);
					  if(mysqli_num_rows($result) > 0)
					  {
				?>
						disabled
				<?php
					  }
					  
				?>
				>21:00 - 24:00</button>
            </td>
        </tr>
    </table>
	</div>
    <p>Note: You can only sign up one slot per week.</p>
    </form>
</body>
</html>
<?php
	$connect->close();
?>
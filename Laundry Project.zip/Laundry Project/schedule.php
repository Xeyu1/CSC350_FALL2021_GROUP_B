<html>
    <body>

        <?php
        if(isset($_POST["name"]))
    
    </body>
</html>

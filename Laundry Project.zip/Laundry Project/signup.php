<?php
$ok = true;

if(isset($_REQUEST["useid"]) && isset($_REQUEST["pwd"])){
    $userid = $_REQUEST["useid"];
    $password = $_REQUEST["pwd"];
    include "dbconnect.php";
    $sql = "SELECT * FROM XXXXX where UserName = '".$userid."' AND UserPwd = '".$password."'";  //create query string
    $result = mysqli_query($connect, $sql);
    if(mysqli_num_rows($result) > 0){  
        $ok = false;
    }
    else{
        $sql = "INSERT INTO XXXXX (UserName, UserPwd) VALUES ('".$userid."','".$password."');"; //create query string
        $result = mysqli_query($connect, $sql);
        $connect->close();
        header("Location: signin.php");   //redirect to register.php
    }
}

$inputtype = "SIGN UP";
$handlername = "signup.php";

include "register.html";
?>
<?php
session_start();
$_SESSION["useid"] = "";
$ok = true;

if(isset($_REQUEST["useid"]) && isset($_REQUEST["pwd"])){
    $userid = $_REQUEST["useid"];
    $password = $_REQUEST["pwd"];
    include "dbconnect.php";
    $sql = "SELECT * FROM XXXXX where UserName = '".$userid."' AND UserPwd";
    $result = mysqli_query($connect, $sql);
    if(mysqli_num_rows($result) > 0){
        $connect->close();
        $_SESSION["useid"] = $userid;
        header("Location: register.html");   //redirect to register.php
    }
    else{
        $ok = false;
    }
}
$inputtype = "SIGN IN";
$handlername = "signin.php";
include "index.php";
?>